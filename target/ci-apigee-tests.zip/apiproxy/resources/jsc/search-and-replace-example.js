function testFunction(){
	'use strict';
	var test = "Mon Oct 12 2015 16:52:48_test";
	return test;
}
//remove comment to see jshint triggering errors
//var a = "test";
/*if(1 === 1) {
	if(2 === 2) {
		if(3 === 3) {
			if(4 === 4) {

			}
		}
	}

}*/

testFunction();